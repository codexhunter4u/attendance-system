/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var usersTablesHeading = [];

usersTablesHeading.alluser = ['Sr.No','User name','User Email','Gender','User Status','User Type','Action'];
usersTablesHeading.reg = ['Sr.No','User name','User Email','Gender','User Status','User DOB','Attendence'];
usersTablesHeading.gender = ['Sr.No','User name','User Email','User Status','User Type','User DOB','Attendence'];